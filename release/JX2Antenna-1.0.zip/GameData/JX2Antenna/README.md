# JX2Antenna
Provides the JX2 Large Deployable Antenna, a large stack-mounted antenna with
transmission power of 1000G. Includes patches for working with various other mods.


## Credits
* Model, texture, and design by: steedcrugeon
* Config files and patches by: Snark


## How to install

Unzip the contents of "GameData" to your GameData folder, same as with most mods.
